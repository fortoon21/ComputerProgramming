import java.io.*;
import java.nio.file.FileAlreadyExistsException;
import java.util.Scanner;

public class Warehouse {
    public final static int stptid=0;
    public final static int stpttype=1;
    public final static int stptname=2;
    public final static int stptprice=3;
    public final static int stptquan=4;
    public final static int txid=0;
    public final static int txtype=1;
    public final static int txptid=2;
    public final static int txptprice=3;
    public final static int txquan=4;
    public final static int txprice=5;
    public final static int stockattrib=5;
    public final static int txattrib=6;

    public String parseCMD(String input, String[][]stock) {
        String[] args = input.split(",");
        if (args[0].equals("I")){
            return imports(args,stock);
        }
        else if(args[0].equals("S")) {
            return sells(args,stock);
        }
        else if(args[0].equals("E")){
            return exchanges(args,stock);
        }
        else{
            return null;
        }
    }

    public static String imports(String [] args, String[][]stock){
        String [] stresult=new String[stockattrib];
        String [] txresult=new String[txattrib];
        boolean flag=false;
        int len=stock.length;
        int ptid=0;

        for(int i=0; i<stock.length;i++){
            if(stock[i][stpttype].equals(args[1])&&stock[i][stptname].equals(args[2])){
                flag=true;
                ptid=i;
                stock[i][stptquan]= ""+(Integer.parseInt(stock[i][stptquan])+Integer.parseInt(args[4]));
                if(Integer.parseInt(stock[i][stptprice])>Integer.parseInt(args[3])){
                    System.out.println("The part became cheap.");
                }
                else{
                    System.out.println("The part became expensive.");
                }
                stock[i][stptprice]=args[3];
            }
        }
        if(!flag){
            stresult[0]=""+stock.length+1;
            ptid=stock.length+1;
            for(int i=1; i<=4; i++){
                stresult[i]=args[i];
            }
            stock=concat(stresult,stock);
        }
        txresult[1]=args[0];
        txresult[2]=ptid+1+"";
        txresult[3]=args[3];
        txresult[4]=args[4];
        txresult[5]=Integer.parseInt(txresult[3])*Integer.parseInt(txresult[4])+"";
        return String.join(",", txresult);
    }

    public static String[][] concat(String[] args,String[][]stock){
        String [][] result=new String[stock.length+1][stockattrib];
        for(int i=0; i<stock.length; i++){
            result[i]=stock[i];
        }
        result[stock.length]=args;
        return result;
    }



    public static String sells(String []args,String[][]stock){
        String [] txresult=new String[txattrib];
        boolean flag=false;
        int len=stock.length;
        int ptid=0;

        for(int i=0; i<stock.length;i++){
            if(stock[i][stpttype].equals(args[1])&&stock[i][stptname].equals(args[2])){
                ptid=i;
                if(Integer.parseInt(stock[i][stptquan])>Integer.parseInt(args[3])){
                    flag=true;
                    stock[i][stptquan]= Integer.parseInt(stock[i][stptquan])-Integer.parseInt(args[3])+"";
                }
                else{
                    return null;
                }
            }
        }
        if(!flag){
            return null;
        }
        txresult[1]=args[0];
        txresult[2]=ptid+1+"";
        txresult[3]=stock[ptid][stptprice];
        txresult[4]=args[3];
        txresult[5]=Integer.parseInt(txresult[3])*Integer.parseInt(txresult[4])+"";

        return String.join(",", txresult);
    }
    public static String exchanges(String []args, String[][]stock){
        String [] txresult=new String[txattrib];
        boolean flag=false;
        int len=stock.length;
        int ptid=0;

        for(int i=0; i<stock.length;i++){
            if(stock[i][stpttype].equals(args[1])&&stock[i][stptname].equals(args[2])){
                ptid=i;
                if(Integer.parseInt(stock[i][stptquan])>Integer.parseInt(args[3])){
                    flag=true;
                }
                else{
                    System.out.println("The part partially exchanged.");
                }
            }
        }
        if(!flag){
            return null;
        }
        txresult[1]=args[0];
        txresult[2]=ptid+1+"";
        txresult[3]=stock[ptid][stptprice];
        txresult[4]=args[3];
        txresult[5]=Integer.parseInt(txresult[3])*Integer.parseInt(txresult[4])+"";
        return String.join(",", txresult);
    }
    public void makestockandtx(String [][] stock, Scanner scan) throws IOException {
        FileWriter txwrite=new FileWriter("tx.txt",true);
        FileWriter stockwrite=new FileWriter("stock.txt", false);
        BufferedWriter txbf=new BufferedWriter(txwrite);
        BufferedWriter stockbf=new BufferedWriter(stockwrite);
        String output;

        while (scan.hasNext()){
            output=parseCMD(scan.nextLine(),stock);
            if(output!=null){
                stockbf.write(output);
                stockbf.newLine();
            }
            else{
                break;
            }
        }

        for(int i=0; i<stock.length;i++){
            stockbf.write(String.join(",", stock[i]));
            stockbf.newLine();
        }
        // BufferedWriter FileWriter를 닫아준다.
        if(txbf != null) try{txbf.close();}catch(IOException e){}
        if(stockbf!= null) try{stockbf.close();}catch(IOException e){}



    }

    public String[][] Readstock(Scanner scan)throws FileNotFoundException{
        int linenumber = 0;

        int i=0;
        while (scan.nextLine() != null){
            linenumber++;
        }
        scan=new Scanner(new File("stock.txt"));
        String input;
        String [] elements;
        String [][] stock=new String[linenumber][stockattrib];

        while(scan.hasNext()){
            input=scan.nextLine();
            elements=input.split(",");
            try {
                for (int j = 0; j < stockattrib; j++) {
                    stock[i][j] = elements[j];
                }
                i++;
            }
            catch (Exception e){
                continue;
            }
        }
        return stock;
    }
    public void main(String []args) throws IOException {
        Scanner scan=new Scanner(new File("stock.txt"));
        String [][] stock=Readstock(scan);
        scan=new Scanner(new File("input.txt"));
        makestockandtx(stock, scan);
    }

}
